const $ = s => document.querySelector(s);
const welcome = $("#welcome"), messagesEl = $("#messages"), input = $("#messageInput");
const form = $("#chatForm"), sendButton = $("#sendButton"), historyList = $("#historyList");
let chats = JSON.parse(localStorage.getItem("jargon_chats") || "[]");
let activeId = null, busy = false, deferredInstallPrompt = null, selectedFile = null, recorder = null, audioChunks = [];

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  $("#installButton").hidden = false;
});
$("#installButton").addEventListener("click", async () => {
  if (!deferredInstallPrompt) {
    toast('In Chrome, open ⋮ and choose "Install app" or "Add to Home screen".');
    return;
  }
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  $("#installButton").hidden = true;
});
window.addEventListener("appinstalled", () => {
  $("#installButton").hidden = true;
  toast("Jargon AI has been installed.");
});
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(err => console.warn("Service worker registration failed:", err)));
}

function save(){localStorage.setItem("jargon_chats",JSON.stringify(chats));renderHistory()}
function current(){return chats.find(c=>c.id===activeId)}
function newChat(){activeId=null;messagesEl.innerHTML="";messagesEl.classList.remove("visible");welcome.style.display="";input.value="";input.focus();$("#sidebar").classList.remove("open")}
function renderHistory(){
  historyList.innerHTML="";
  if(!chats.length){historyList.innerHTML='<p class="empty-history">Your conversations will appear here.</p>';return}
  [...chats].reverse().forEach(chat=>{const b=document.createElement("button");b.className="history-entry";b.textContent=chat.title||"New conversation";b.title=b.textContent;b.onclick=()=>loadChat(chat.id);historyList.appendChild(b)});
}
function loadChat(id){const c=chats.find(x=>x.id===id);if(!c)return;activeId=id;welcome.style.display="none";messagesEl.classList.add("visible");messagesEl.innerHTML="";c.messages.forEach(m=>appendMessage(m.role,m.content,false));input.focus();$("#sidebar").classList.remove("open")}
function appendMessage(role,content,tools=true){
  const row=document.createElement("div");row.className=`message ${role}`;
  if(role==="assistant"){const av=document.createElement("div");av.className="avatar";av.textContent="A";row.appendChild(av)}
  const wrap=document.createElement("div"),bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content;wrap.appendChild(bubble);
  if(role==="assistant"&&tools){const actions=document.createElement("div");actions.className="message-tools";const copy=document.createElement("button");copy.className="copy-btn";copy.textContent="Copy response";copy.onclick=async()=>{try{await navigator.clipboard.writeText(content);toast("Response copied")}catch{toast("Copy is not available in this browser")}};actions.appendChild(copy);wrap.appendChild(actions)}
  row.appendChild(wrap);messagesEl.appendChild(row);row.scrollIntoView({block:"end",behavior:"smooth"});return row;
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function setBusy(v){busy=v;sendButton.disabled=v;sendButton.querySelector("span").textContent=v?"Thinking":"Send"}
async function send(text){
  text=text.trim();if(!text||busy)return;
  if(!activeId){activeId=crypto.randomUUID();chats.push({id:activeId,title:text.slice(0,38),messages:[]})}
  const chat=current();chat.messages.push({role:"user",content:text});welcome.style.display="none";messagesEl.classList.add("visible");appendMessage("user",text,false);input.value="";input.style.height="auto";save();setBusy(true);
  const typing=appendMessage("assistant","",false);typing.querySelector(".bubble").innerHTML='<span class="typing"><i></i><i></i><i></i></span>';
  try{
    const body=new FormData();body.append("messages",JSON.stringify(chat.messages));body.append("webSearch",String($("#webSearchToggle").checked));if(selectedFile)body.append("file",selectedFile);const res=await fetch("/api/chat",{method:"POST",body});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"Something went wrong.");
    chat.messages.push({role:"assistant",content:data.reply});typing.remove();appendMessage("assistant",data.reply);if(selectedFile){toast(`Analysed ${selectedFile.name}`);selectedFile=null;$("#fileInput").value="";$("#attachmentNote").hidden=true;}save();
  }catch(err){typing.remove();appendMessage("assistant",`I couldn't connect just now. ${err.message}`)}
  finally{setBusy(false);input.focus()}
}
form.addEventListener("submit",e=>{e.preventDefault();send(input.value)});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,150)+"px"});
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
$("#newChat").onclick=newChat;$("#historyJump").onclick=()=>historyList.scrollIntoView({behavior:"smooth",block:"nearest"});$("#menuToggle").onclick=()=>$("#sidebar").classList.toggle("open");
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.dataset.prompt)));
renderHistory();

// Cross-platform file attachment, voice transcription and spoken responses.
$("#fileInput").addEventListener("change",e=>{selectedFile=e.target.files?.[0]||null;const n=$("#attachmentNote");n.hidden=!selectedFile;n.textContent=selectedFile?`Attached: ${selectedFile.name} (${Math.round(selectedFile.size/1024)} KB)`:'';});
$("#voiceButton").addEventListener("click",async()=>{if(recorder&&recorder.state==='recording'){recorder.stop();$("#voiceButton").textContent='🎙 Voice';return;}try{if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Voice recording is not supported in this browser.');const stream=await navigator.mediaDevices.getUserMedia({audio:true});audioChunks=[];recorder=new MediaRecorder(stream);recorder.ondataavailable=e=>{if(e.data.size)audioChunks.push(e.data)};recorder.onstop=async()=>{stream.getTracks().forEach(t=>t.stop());try{const fd=new FormData();fd.append('audio',new Blob(audioChunks,{type:recorder.mimeType||'audio/webm'}),'recording.webm');const r=await fetch('/api/audio/transcribe',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw new Error(d.error||'Transcription failed');input.value=(input.value+' '+d.text).trim();input.focus();toast('Voice converted to text. Press Send when ready.');}catch(err){toast(err.message)}};recorder.start();$("#voiceButton").textContent='■ Stop recording';}catch(err){toast(err.message||'Microphone permission is needed.');}});
$("#imageToolButton").addEventListener('click',()=>{$("#generatedImageResult").innerHTML='';$("#imagePrompt").value='';$("#imageDialog").showModal();});
$("#generateImageButton").addEventListener('click',async()=>{const b=$("#generateImageButton"),out=$("#generatedImageResult"),prompt=$("#imagePrompt").value.trim();if(!prompt){toast('Describe the image first.');return;}b.disabled=true;b.querySelector('span').textContent='Creating...';out.textContent='Jargon is creating your image. This may take a moment.';try{const r=await fetch('/api/images/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Image generation failed');const img=document.createElement('img');img.src=d.image;img.alt=prompt;img.className='generated-image';out.innerHTML='';out.appendChild(img);const link=document.createElement('a');link.href=d.image;link.download='jargon-ai-image.png';link.textContent='Save image';out.appendChild(link);}catch(e){out.textContent=e.message;}finally{b.disabled=false;b.querySelector('span').textContent='Generate image';}});
// Add a speak button to assistant messages using the server-side speech endpoint.
const originalAppendMessage=appendMessage;
appendMessage=function(role,content,tools=true){const row=originalAppendMessage(role,content,tools);if(role==='assistant'&&content){const wrap=row.lastElementChild,button=document.createElement('button');button.className='copy-btn';button.textContent='🔊 Listen';button.onclick=async()=>{button.disabled=true;try{const r=await fetch('/api/audio/speech',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:content})});if(!r.ok){const d=await r.json();throw new Error(d.error||'Speech unavailable');}const audio=new Audio(URL.createObjectURL(await r.blob()));audio.play();audio.onended=()=>URL.revokeObjectURL(audio.src);}catch(e){toast(e.message)}finally{button.disabled=false}};wrap.appendChild(button);}return row;};
