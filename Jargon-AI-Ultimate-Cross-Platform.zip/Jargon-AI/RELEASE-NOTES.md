# Jargon AI Ultimate Edition 3.0

Cross-platform source package based on the earlier Jargon AI PWA. Added Capacitor scaffolding for native Android and iOS builds, image/document attachments, optional web search, image generation, voice transcription and text-to-speech. See README for setup and limitations.
